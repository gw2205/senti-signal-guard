# Placeholder for MEXC API functions
def get_price(symbol):
    return 1.23  # Mocked price